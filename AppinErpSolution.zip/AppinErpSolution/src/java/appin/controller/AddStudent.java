package appin.controller;

import com.dbconfig.DatabaseConfig;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author YASH
 */
@MultipartConfig(maxFileSize = 16177215)
public class AddStudent extends HttpServlet {

    int s_id;
    String message = null;
    String fmonth = "0";
    String monthInString = null;
    int month;
    static String stud_course_appin;
    static String stud_course_type;
    static String stud_id;
    static String stud_name;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            
            //String stud_id = request.getParameter("stud_id");
            stud_name = request.getParameter("stud_name");
            //String stud_form_number = request.getParameter("stud_form_number");
            stud_course_type = request.getParameter("stud_course_type");
            stud_course_appin = request.getParameter("stud_course_months");
            String stud_regis_date = request.getParameter("stud_regis_date");
            Date d_stud_regis_date = new SimpleDateFormat("yyyy-MM-dd").parse(stud_regis_date);

            String stud_addmission_date = request.getParameter("stud_addmission_date");
            Date d_stud_addmission_date = new SimpleDateFormat("yyyy-MM-dd").parse(stud_addmission_date);

            String stud_batch_timing = request.getParameter("stud_batch_timing");

            String batch_intake_date = request.getParameter("batch_intake_date");
            Date d_batch_intake_date = new SimpleDateFormat("yyyy-MM-dd").parse(batch_intake_date);

            String stud_gender = request.getParameter("stud_gender");

            String stud_dob = request.getParameter("stud_dob");
            Date d_stud_dob = new SimpleDateFormat("yyyy-MM-dd").parse(stud_dob);

            String stud_address = request.getParameter("stud_address");
            String stud_pincode = request.getParameter("stud_pincode");
            String stud_uid = request.getParameter("stud_uid");
            String stud_state = request.getParameter("stud_state");
            String stud_country = request.getParameter("stud_country");
            //Long stud_telephone = Long.parseLong(request.getParameter("stud_telephone"));
            String stud_mobile = request.getParameter("stud_mobile");
            String stud_email = request.getParameter("stud_email");
            String stud_alter_email = request.getParameter("stud_alter_email");
            String stud_father_name = request.getParameter("stud_father_name");
            String stud_father_occupation = request.getParameter("stud_father_occupation");
            String stud_father_mobile = request.getParameter("stud_father_mobile");
            String stud_father_uid = request.getParameter("stud_father_uid");
            String stud_result_mode = request.getParameter("stud_result_mode");
            String stud_result_mode_details = request.getParameter("stud_result_mode_details");
            String stud_college_course = request.getParameter("stud_college_course");
            String stud_college_branch = request.getParameter("stud_college_branch");
            String stud_college_sem = request.getParameter("stud_college_sem");
            String stud_college_name = request.getParameter("stud_college_name");
            String office_counselor = request.getParameter("office_counselor");
            String office_tele_counselor = request.getParameter("office_tele_counselor");
            String office_kiosk = request.getParameter("office_kiosk");
            String office_source = request.getParameter("office_source");

            //Database file access
            DatabaseConfig.connectDB();

            String sql = "select s_id from regis_form where s_id = (SELECT max(s_id) from regis_form) ; ";
            PreparedStatement pst = DatabaseConfig.conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                s_id = rs.getInt("s_id");
            }

            //Append Addmission month and year with student ID:
            Calendar cal = Calendar.getInstance();
            cal.setTime(d_stud_addmission_date);
            int year = cal.get(Calendar.YEAR);

            month = cal.get(Calendar.MONTH) + 1;

            if (month < 10) {
                monthInString = fmonth.concat(String.valueOf(month));
            }
            if (month >= 10) {
                monthInString = String.valueOf(month);
            }

            System.out.println(year);
            System.out.println(monthInString);

            //Student ID creation.....
            stud_id = stud_course_type + "" + stud_course_appin + "/" + monthInString + "" + year + "/" + (s_id + 1);
            System.out.println(stud_id);

            //Student Form number......
            String stud_form_number = "FRM/" + stud_id;
            System.out.println(stud_form_number);

            //Form query
            String query = "INSERT INTO regis_form VALUES (?, ?, ?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement statement = DatabaseConfig.conn.prepareStatement(query);
            
            statement.setNull(1, 0); //For sid (PK)
            statement.setString(2, stud_id);
            statement.setString(3, stud_form_number);
            statement.setString(4, stud_course_type);
            statement.setString(5, stud_course_appin);
            statement.setDate(6, new java.sql.Date(d_stud_regis_date.getTime()));
            statement.setDate(7, new java.sql.Date(d_stud_addmission_date.getTime()));
            statement.setString(8, stud_batch_timing);
            statement.setDate(9, new java.sql.Date(d_batch_intake_date.getTime()));
            statement.setString(10, stud_name);
            statement.setString(11, stud_gender);
            statement.setDate(12, new java.sql.Date(d_stud_dob.getTime()));
            statement.setString(13, stud_address);
            statement.setString(14, stud_pincode);
            statement.setString(15, stud_uid);
            statement.setString(16, stud_state);
            statement.setString(17, stud_country);
            //statement.setLong(18, stud_telephone);
            statement.setString(18, stud_mobile);
            statement.setString(19, stud_email);
            statement.setString(20, stud_alter_email);
            statement.setString(21, stud_father_name);
            statement.setString(22, stud_father_occupation);
            statement.setString(23, stud_father_mobile);
            statement.setString(24, stud_father_uid);
            statement.setString(25, stud_result_mode);
            statement.setString(26, stud_result_mode_details);
            statement.setString(27, stud_college_course);
            statement.setString(28, stud_college_branch);
            statement.setString(29, stud_college_sem);
            statement.setString(30, stud_college_name);
            statement.setString(31, office_counselor);
            statement.setString(32, office_tele_counselor);
            statement.setString(33, office_kiosk);
            statement.setString(34, office_source);
            
            
            //Student login query
            String query_login = "INSERT INTO stud_login VALUES (?, ?)";
            PreparedStatement statement2 = DatabaseConfig.conn.prepareStatement(query_login);
            
            statement2.setString(1, stud_id);
            statement2.setString(2, "12345");
            
            
            //for dispatch documents repository
            String dispatch_details = "INSERT INTO dispatch_details VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement3 = DatabaseConfig.conn.prepareStatement(dispatch_details);

            statement3.setString(1, stud_id);
            statement3.setString(2, stud_name);
            statement3.setString(3, "not_dispatched");
            statement3.setString(4, "not_dispatched");
            statement3.setString(5, "not_dispatched");
            statement3.setString(7, "not_dispatched");
            statement3.setString(8, "not_dispatched");
            statement3.setString(9, "not_dispatched");
            statement3.setString(10, "not_dispatched");
            statement3.setString(11, "not_dispatched");
            statement3.setString(12, "not_dispatched");
            statement3.setString(13, "not_dispatched");
            statement3.setString(16, "not_dispatched");
            statement3.setString(18, "not_dispatched");
            statement3.setString(19, "not_dispatched");
            statement3.setString(20, "not_dispatched");
            if (stud_id.startsWith("T")) {
                statement3.setString(6, "NA");
                statement3.setString(14, "NA");
                statement3.setString(15, "NA");
                statement3.setString(17, "not_dispatched");
                statement3.setString(21, "not_dispatched");
                statement3.setString(22, "NA");
                statement3.setString(23, "NA");
            }
            if (stud_id.startsWith("NT")) {
                statement3.setString(6, "not_dispatched");
                statement3.setString(14, "not_dispatched");
                statement3.setString(15, "not_dispatched");
                statement3.setString(17, "NA");
                if (Integer.parseInt(stud_course_appin) >= 15) {
                    statement3.setString(21, "NA");
                } else {
                    statement3.setString(21, "not_dispatched");
                }
                statement3.setString(22, "not_dispatched");
                statement3.setString(23, "not_dispatched");
            }
            
            //Student profile picture path query
            String query_dp = "INSERT INTO profile_picture VALUES (?, ?)";
            PreparedStatement statement4 = DatabaseConfig.conn.prepareStatement(query_dp);
            
            statement4.setString(1, stud_id);
            statement4.setString(2, "");
            

            //method to store technology details by default
            storeTechnologiesDetails();

            int row = statement.executeUpdate();
            System.out.println("Data stored successfully..." + row);

            int row2 = statement2.executeUpdate();
            System.out.println("Data stored successfully in login table" + row2);

            int row3 = statement3.executeUpdate();
            System.out.println("Data stored successfully in dispatch table" + row3);
            
            int row4 = statement4.executeUpdate();
            System.out.println("Data stored successfully in display picture table" + row4);

            statement.close();
            statement2.close();
            statement3.close();
            statement4.close();
            DatabaseConfig.conn.close();
        } catch (SQLException ex) {
            message = "ERROR: " + ex.getMessage();
            ex.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException ex) {
            Logger.getLogger(AddStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(AddStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(AddStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(AddStudent.class.getName()).log(Level.SEVERE, null, ex);
        }
        request.setAttribute("Stu_ID", stud_id);
        getServletConfig().getServletContext().getRequestDispatcher("/FormSuccess.jsp").forward(request, response);
    }

    public void storeTechnologiesDetails() {
        if (stud_course_type.startsWith("T")) {
            try {
                String technology_details = "INSERT INTO tech_technology VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pst = DatabaseConfig.conn.prepareStatement(technology_details);

                pst.setString(1, stud_id);
                pst.setString(2, stud_name);
                pst.setString(3, "Not_Completed");
                pst.setString(4, "Not_Completed");
                pst.setString(5, "Not_Completed");
                pst.setString(6, "Not_Completed");
                pst.setString(7, "Not_Completed");
                pst.setString(8, "Not_Completed");
                pst.setString(9, "Not_Completed");
                pst.setString(10, "Not_Completed");
                pst.setString(11, "Not_Completed");
                pst.setString(12, "Not_Completed");
                pst.setString(13, "Not_Completed");
                if (stud_course_appin.equals("10") || stud_course_appin.equals("FT")) {
                    pst.setString(14, "NA");
                    pst.setString(15, "NA");
                    pst.setString(16, "NA");
                    pst.setString(17, "NA");
                    pst.setString(18, "NA");
                } else if (stud_course_appin.equals("16")) {
                    pst.setString(14, "Not_Completed");
                    pst.setString(15, "Not_Completed");
                    pst.setString(16, "NA");
                    pst.setString(17, "NA");
                    pst.setString(18, "NA");
                } else if (stud_course_appin.equals("18")) {
                    pst.setString(14, "Not_Completed");
                    pst.setString(15, "Not_Completed");
                    pst.setString(16, "Not_Completed");
                    pst.setString(17, "Not_Completed");
                    pst.setString(18, "Not_Completed");
                } else {
                    
                }
                int row4 = pst.executeUpdate();
                System.out.println("Data stored successfully in tech-technology table" + row4);

                pst.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddStudent.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (stud_course_type.startsWith("NT")) {
            try {
                String technology_details = "INSERT INTO ntech_technology VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pst = DatabaseConfig.conn.prepareStatement(technology_details);

                pst.setString(1, stud_id);
                pst.setString(2, stud_name);
                pst.setString(3, "Not_Completed");
                pst.setString(4, "Not_Completed");
                pst.setString(5, "Not_Completed");
                pst.setString(6, "Not_Completed");
                pst.setString(7, "Not_Completed");
                if (stud_course_appin.equals("7")) {
                    pst.setString(8, "NA");
                    pst.setString(9, "NA");
                    pst.setString(10, "NA");
                    pst.setString(11, "NA");
                    pst.setString(12, "NA");
                    pst.setString(13, "NA");
                    pst.setString(14, "NA");
                    pst.setString(15, "NA");
                    pst.setString(16, "NA");
                    pst.setString(17, "NA");
                    pst.setString(18, "NA");
                    pst.setString(19, "NA");
                } else if (stud_course_appin.equals("11")) {
                    pst.setString(8, "Not_Completed");
                    pst.setString(9, "Not_Completed");
                    pst.setString(10, "Not_Completed");
                    pst.setString(11, "NA");
                    pst.setString(12, "NA");
                    pst.setString(13, "NA");
                    pst.setString(14, "NA");
                    pst.setString(15, "NA");
                    pst.setString(16, "NA");
                    pst.setString(17, "NA");
                    pst.setString(18, "NA");
                    pst.setString(19, "NA");
                } else if (stud_course_appin.equals("13")) {
                    pst.setString(8, "Not_Completed");
                    pst.setString(9, "Not_Completed");
                    pst.setString(10, "Not_Completed");
                    pst.setString(11, "Not_Completed");
                    pst.setString(12, "Not_Completed");
                    pst.setString(13, "Not_Completed");
                    pst.setString(14, "NA");
                    pst.setString(15, "NA");
                    pst.setString(16, "NA");
                    pst.setString(17, "NA");
                    pst.setString(18, "NA");
                    pst.setString(19, "NA");
                } else if (stud_course_appin.equals("15")) {
                    pst.setString(8, "Not_Completed");
                    pst.setString(9, "Not_Completed");
                    pst.setString(10, "Not_Completed");
                    pst.setString(11, "Not_Completed");
                    pst.setString(12, "Not_Completed");
                    pst.setString(13, "Not_Completed");
                    pst.setString(14, "Not_Completed");
                    pst.setString(15, "Not_Completed");
                    pst.setString(16, "NA");
                    pst.setString(17, "NA");
                    pst.setString(18, "NA");
                    pst.setString(19, "NA");
                } else if (stud_course_appin.equals("17")) {
                    pst.setString(8, "Not_Completed");
                    pst.setString(9, "Not_Completed");
                    pst.setString(10, "Not_Completed");
                    pst.setString(11, "Not_Completed");
                    pst.setString(12, "Not_Completed");
                    pst.setString(13, "Not_Completed");
                    pst.setString(14, "Not_Completed");
                    pst.setString(15, "Not_Completed");
                    pst.setString(16, "Not_Completed");
                    pst.setString(17, "NA");
                    pst.setString(18, "NA");
                    pst.setString(19, "NA");
                } else if (stud_course_appin.equals("21")) {
                    pst.setString(8, "Not_Completed");
                    pst.setString(9, "Not_Completed");
                    pst.setString(10, "Not_Completed");
                    pst.setString(11, "Not_Completed");
                    pst.setString(12, "Not_Completed");
                    pst.setString(13, "Not_Completed");
                    pst.setString(14, "Not_Completed");
                    pst.setString(15, "Not_Completed");
                    pst.setString(16, "Not_Completed");
                    pst.setString(17, "Not_Completed");
                    pst.setString(18, "Not_Completed");
                    pst.setString(19, "NA");
                } else if (stud_course_appin.equals("23")) {
                    pst.setString(8, "Not_Completed");
                    pst.setString(9, "Not_Completed");
                    pst.setString(10, "Not_Completed");
                    pst.setString(11, "Not_Completed");
                    pst.setString(12, "Not_Completed");
                    pst.setString(13, "Not_Completed");
                    pst.setString(14, "Not_Completed");
                    pst.setString(15, "Not_Completed");
                    pst.setString(16, "Not_Completed");
                    pst.setString(17, "Not_Completed");
                    pst.setString(18, "Not_Completed");
                    pst.setString(19, "Not_Completed");
                } else {

                }
                int row4 = pst.executeUpdate();
                System.out.println("Data stored successfully in technology mapping table table" + row4);

                pst.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddStudent.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
