package com.batch;

import com.dbconfig.DatabaseConfig;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author YASH
 */
public class AddNewBatch extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            PrintWriter out = response.getWriter();
            String batch_start_date = request.getParameter("batch_start_date");
            Date d_batch_start_date = new SimpleDateFormat("yyyy-MM-dd").parse(batch_start_date);
            String batch_technology = request.getParameter("batch_technology");
            String assign_faculty = request.getParameter("assign_faculty");

            String start_time = request.getParameter("start_time");
            Date d_start_time = new SimpleDateFormat("hh:mm").parse(start_time);

            String end_time = request.getParameter("end_time");
            Date d_end_time = new SimpleDateFormat("hh:mm").parse(end_time);

            //Logic for batch name generation
            String batch_name = batch_technology + "-" + batch_start_date;

            DatabaseConfig.connectDB();
            String query = "INSERT INTO batch_created VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = DatabaseConfig.conn.prepareStatement(query);

            statement.setString(1, batch_name);
            statement.setDate(2, new java.sql.Date(d_batch_start_date.getTime()));
            statement.setString(3, batch_technology);
            statement.setString(4, assign_faculty);
            statement.setTime(5, new java.sql.Time(d_start_time.getTime()));
            statement.setTime(6, new java.sql.Time(d_end_time.getTime()));

            int row = statement.executeUpdate();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Batch Created Successfully.....');");
            out.println("location='batchCreation.jsp';");
            out.println("</script>");
            System.out.println("Data stored successfully..." + row);

        } catch (ParseException ex) {
            Logger.getLogger(AddNewBatch.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddNewBatch.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(AddNewBatch.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(AddNewBatch.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AddNewBatch.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
