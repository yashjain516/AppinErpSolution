package com.batch;

import com.dbconfig.DatabaseConfig;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author YASH
 */
public class AddBatchStudent extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            PrintWriter out = response.getWriter();
            String batch_technology = request.getParameter("batch_technology");
            String stud_id[] = request.getParameterValues("stud_id");

            DatabaseConfig.connectDB();
            PreparedStatement statement = null;
            for (int i = 0; i < stud_id.length; i++) {
                String query = "INSERT INTO batch_scheduled VALUES (?, ?)";
                statement = DatabaseConfig.conn.prepareStatement(query);
                statement.setString(1, batch_technology);
                statement.setString(2, stud_id[i]);
                int row = statement.executeUpdate();
            }

            out.println("<script type=\"text/javascript\">");
            out.println("alert('Batch Scheduled Successfully.....');");
            out.println("location='batchSchedule.jsp';");
            out.println("</script>");
            //response.sendRedirect("batchAlert.jsp");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddBatchStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(AddBatchStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(AddBatchStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AddBatchStudent.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
