package com.dbconfig;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author YASH
 */
public class DatabaseConfig {
    public static Connection conn = null;
    public static void connectDB() throws ClassNotFoundException, IllegalAccessException, InstantiationException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        //conn = DriverManager.getConnection("jdbc:mysql://node21426-env-7586951.mj.milesweb.cloud/appin_accounts?user=root&password=LCMavg66712");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/appin_accounts?user=root&password=root");
    }
    public static void disConnectDB()
    {
        if (conn != null) {
	                // closes the database connection
	                try {
	                    conn.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
	}
    }
}
