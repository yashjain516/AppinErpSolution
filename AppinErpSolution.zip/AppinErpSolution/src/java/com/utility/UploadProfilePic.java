package com.utility;

import com.dbconfig.DatabaseConfig;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UploadProfilePic {
    public static void UploadPicture(String url, String stud_id)
    {
        String updatedUrl = stud_id.replace("/", "-") + "/" + url.substring(url.lastIndexOf("/")+1);
        try {
            DatabaseConfig.connectDB();
            String query = "update profile_picture set path='" + updatedUrl + "' where stud_id = '" + stud_id + "'";
            PreparedStatement pst = DatabaseConfig.conn.prepareStatement(query);
            
            int row = pst.executeUpdate();
            System.out.println("Data updated successfully..." + row);
            
            pst.close();
            DatabaseConfig.conn.close();
        } catch (SQLException ex) {
            System.out.println("Sql Exception....."+ex);
        } catch (Exception e) {
            System.out.println("Exception......");
        }
        
    }
}
