/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.utility;

import com.dbconfig.DatabaseConfig;
import java.io.IOException;
//import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author YASH
 */
public class FormValidation extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            //PrintWriter out = request.getContentType();
            String user = request.getParameter("user");
            String pass = request.getParameter("pass");
            
            DatabaseConfig.connectDB();
            //out.print("<h1>hello</h1>");
            String sql = "select * from mgmt_login where user_id = ? and password = ?";
            PreparedStatement pst = DatabaseConfig.conn.prepareStatement(sql);

            pst.setString(1, user);
            pst.setString(2, pass);
            ResultSet rs = pst.executeQuery();
            if (rs.next() && user.equals(rs.getString("user_id")) && pass.equals(rs.getString("password"))) {
                HttpSession session = request.getSession();
                //request.setAttribute("userName", rs.getString("user_id"));
                session.setAttribute("currentID", user);
                session.setAttribute("userRole", rs.getString("role"));
                response.sendRedirect("index.jsp");
            } else {
                System.out.println("Credential do not match");
                response.sendRedirect("failureLogin.jsp");
            }
            pst.close();
            DatabaseConfig.conn.close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FormValidation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(FormValidation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(FormValidation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(FormValidation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
